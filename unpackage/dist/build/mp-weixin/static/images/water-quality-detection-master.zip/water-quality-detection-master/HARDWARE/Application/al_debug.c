//硬件驱动
#include "stm32f10x.h"
#include "al_debug.h"
#include "usart.h"
#include "delay.h"

//C库
#include <stdarg.h>
#include <string.h>
#include <stdio.h>

al_sysconfig_t g_sysconfig;
/*
************************************************************
*	函数名称：	UsartPrintf
*
*	函数功能：	格式化打印
*
*	入口参数：	USARTx：串口组
*				fmt：不定长参
*
*	返回参数：	无
*
*	说明：
************************************************************
*/
void AL_DEBUG_LOG(USART_TypeDef* USARTx, char* fmt, ...)
{
    if(AL_DEBUG_FILE_DEBUG)
    {
        unsigned char UsartPrintfBuf[296];
        va_list ap;
        unsigned char* pStr = UsartPrintfBuf;

        va_start(ap, fmt);
        vsnprintf((char*)UsartPrintfBuf, sizeof(UsartPrintfBuf), fmt, ap);							//格式化
        va_end(ap);

        while(*pStr != 0)
        {
            USART_SendData(USARTx, *pStr++);
            while(USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);
        }
    }
}

void al_main_task_log_start(void)
{
	al_debug_log(" Application version: %s",g_version);
	delay_ms(1000);
}

