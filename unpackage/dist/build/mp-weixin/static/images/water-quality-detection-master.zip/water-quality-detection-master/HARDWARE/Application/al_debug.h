#ifndef AL_DEBUG_H
#define AL_DEBUG_H

#include "stm32f10x.h"
#include "al_debug.h"
#include "stdio.h"
#include <stdint.h>

typedef struct
{
	float PH;
	char char_PH[5];
	float PH_t;
	
	int ds18b20;
	short ds18b20_data;
	float f_ds18b20;
	char char_ds18b20[10];  // 转换后的真实温度
	
	u16 Tds_adc,Tds_value;
	float Tds_voltage;
	char char_Tds_value[10];  // 转换后的TDS值
	uint16_t Tds_t;
	
}al_sysconfig_t;

extern al_sysconfig_t g_sysconfig;

#define g_version	"General_App_V1.0.0"

#define al_debug_log(format, ...) printf("<ST>F:"__FILE__"\tL:%d>> "format"<END>\r\n",__LINE__,##__VA_ARGS__)

#ifndef AL_DEBUG_FILE_DEBUG
#define AL_DEBUG_FILE_DEBUG			1
#endif

#define USART1_DEBUG		USART1		//调试打印所使用的串口组
#define USART2_DEBUG		USART2
#define USART3_DEBUG		USART3

void AL_DEBUG_LOG(USART_TypeDef *USARTx, char *fmt,...);
void al_main_task_log_start(void);

#endif

