#include "stm32f10x.h"
#include "aqi.h"

float C_low,C_high,I_low,I_high;
uint16_t PM2_5_AQI,PM10_AQI,CO_AQI;

float calculate_data_pm2_5aqi_task(float data)
{
	float AQI;
	if(data > 0 && data < 35)
	{
		C_low = 0;C_high = 35;
		I_low = 0;I_high = 50;
	}
	else if(data > 35 && data < 75)
	{
		C_low = 35;C_high = 75;
		I_low = 50;I_high = 100;
	}
	else if(data > 75 && data < 115)
	{
		C_low = 75;C_high = 115;
		I_low = 100;I_high = 150;
	}
	else if(data > 115 && data < 150)
	{
		C_low = 115;C_high = 150;
		I_low = 150;I_high = 200;
	}
	else if(data > 150 && data < 250)
	{
		C_low = 150;C_high = 250;
		I_low = 200;I_high = 300;
	}
	else if(data > 250 && data < 350)
	{
		C_low = 250;C_high = 350;
		I_low = 300;I_high = 400;
	}
	else if(data > 350 && data < 500)
	{
		C_low = 350;C_high = 500;
		I_low = 400;I_high = 500;
	}
	
	AQI = (I_high - I_low) / (C_high - C_low) * (data - C_low) + I_low;
	return AQI;
}


float calculate_data_pm10aqi_task(float data)
{
	float AQI;
	if(data > 0 && data < 50)
	{
		C_low = 0;C_high = 50;
		I_low = 0;I_high = 50;
	}
	else if(data > 50 && data < 150)
	{
		C_low = 50;C_high = 150;
		I_low = 50;I_high = 100;
	}
	else if(data > 150 && data < 250)
	{
		C_low = 150;C_high = 250;
		I_low = 100;I_high = 150;
	}
	else if(data > 250 && data < 350)
	{
		C_low = 250;C_high = 350;
		I_low = 150;I_high = 200;
	}
	else if(data > 350 && data < 420)
	{
		C_low = 350;C_high = 420;
		I_low = 200;I_high = 300;
	}
	else if(data > 420 && data < 500)
	{
		C_low = 420;C_high = 500;
		I_low = 300;I_high = 400;
	}
	else if(data > 500 && data < 600)
	{
		C_low = 500;C_high = 600;
		I_low = 400;I_high = 500;
	}
	
	AQI = (I_high - I_low) / (C_high - C_low) * (data - C_low) + I_low;
	return AQI;
}

float calculate_data_coaqi_task(float data)
{
	float AQI;
	if(data >= 0 && data < 5)
	{
		C_low = 0;C_high = 5;
		I_low = 0;I_high = 50;
	}
	else if(data > 5 && data < 10)
	{
		C_low = 5;C_high = 10;
		I_low = 50;I_high = 100;
	}
	else if(data > 10 && data < 35)
	{
		C_low = 10;C_high = 35;
		I_low = 100;I_high = 150;
	}
	else if(data > 35 && data < 60)
	{
		C_low = 35;C_high = 60;
		I_low = 150;I_high = 200;
	}
	else if(data > 60 && data < 90)
	{
		C_low = 60;C_high = 90;
		I_low = 200;I_high = 300;
	}
	else if(data > 90 && data < 120)
	{
		C_low = 90;C_high = 120;
		I_low = 300;I_high = 400;
	}
	else if(data > 120 && data < 150)
	{
		C_low = 120;C_high = 150;
		I_low = 400;I_high = 500;
	}
	else if(data >= 150)
	{
		C_low = 120;C_high = 150;
		I_low = 400;I_high = 500; 
	}
	
	AQI = (I_high - I_low) / (C_high - C_low) * (data - C_low) + I_low;
	return AQI;
}

