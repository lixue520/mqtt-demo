#ifndef __AQI_H
#define __AQI_H	 
#include "sys.h"

extern float calculate_data_pm2_5aqi_task(float data);
extern float calculate_data_pm10aqi_task(float data);
extern float calculate_data_coaqi_task(float data);

extern float C_low,C_high,I_low,I_high;
extern uint16_t PM2_5_AQI,PM10_AQI,CO_AQI;

#endif
