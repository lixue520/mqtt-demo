#ifndef _ESP8266_H_
#define _ESP8266_H_

#include "sys.h"

extern char HTTP_Buf[1024]; //HTTP

typedef struct
{
	char Year[5];
	char Mon[5];
	char day[5];
	char Hour[5];
	char Min[5];
	char Sec[5];
}CCLK;
extern CCLK cclk;

typedef struct   //�ṹ�塣
{
    vu16  year;
    vu8   month;
    vu8   date;
    vu8   hour;
    vu8   min;
    vu8   sec;	 
}nt_calendar_obj;
extern nt_calendar_obj nwt;

extern u8 connect_server_flag;

void ESP8266_Init(void);
void ESP8266_AP_Init(void);
void ESP8266_STA_Init(void);

void ESP8266_Clear(void);

void ESP8266_SendData(unsigned char *data, unsigned short len);

unsigned char *ESP8266_GetIPD(unsigned short timeOut);

void al_main_task_esp8266_recv_serverdata(void);

extern u8 bedroom_model, drawingroom_model, toilet_model;
extern unsigned char esp8266_buf[128];
extern unsigned short esp8266_cnt, esp8266_cntPre;
extern u8 bedroom_infrare_state, toilet_infrare_state;

extern _Bool ESP8266_SendCmd(char *cmd, char *res);
extern void get_beijing_time_task(void);
extern uint32_t HTTP_PostPkt(char *pkt, char *key, char *devid, char *k0, float val, char *k1, u16 k2, char *k3, float k4);
#endif
