#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define BEEP PBout(8)	// PB8

void LED_Init(void);		//��ʼ��
void BEEP_Init(void);

#endif
